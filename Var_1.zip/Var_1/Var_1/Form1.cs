﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Var_1
{
    public partial class Form1 : Form
    {
        Posh a = new Posh();
        Posh b = new Posh();
        Posh c = new Posh();
        ArrayList poch = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Заполните пустые поля");
            }
            else
            {
                a.St(textBox1.Text);
                b.Ci(textBox2.Text);
                c.Co(textBox3.Text);
                poch.Add(a);
                poch.Add(b);
                poch.Add(c);
                string file = "file.txt";
                string[] s = File.ReadAllLines(file);
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i].Contains(listBox1.Text))
                    {
                        s[i] = $"Город: {textBox1.Text}, Улица: {textBox2.Text}, Код: {textBox3.Text}";
                    }
                }
                File.WriteAllLines(file, s);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("file.txt"))
            {
                StreamReader sw = File.OpenText("file.txt");
                while (!sw.EndOfStream)
                {
                    string s = sw.ReadLine();
                    listBox1.Items.Add(s);
                    poch.Add(s);
                }
                sw.Close();
            }
            else
            {
                MessageBox.Show("Файла нет");
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            poch.Clear();
            listBox1.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            button1.Enabled = true;
        }
    }
}
