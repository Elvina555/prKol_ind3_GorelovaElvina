﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Var_1
{
    internal class Posh
    {
        public string Gorod { get; set; }
        public string Yliz { get; set; }
        public string Code { get; set; }

        public void St(string n)
        {
            this.Gorod = n;
        }
        public void Ci(string n1)
        {
            this.Yliz = n1;
        }
        public void Co(string n3)
        {
            this.Code = n3;
        }
    }
}
